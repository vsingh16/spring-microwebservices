package hello.controller;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Created by vishal on 20-Feb-18.
 */
@RestController
public class HelloWorldController {

    @GetMapping("/hello")
    @HystrixCommand(fallbackMethod = "fallbackHello")
    public String hello() {
        throw new RuntimeException("Hystrix test example");
    }

    public String fallbackHello() {
        return "Hystrix Hello";
    }
}
